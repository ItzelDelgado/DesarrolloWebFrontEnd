Itzel Azucena Delgado Díaz

Debemos ejecutar el api antes de correr el programa.

Para correr el programa deberemos colocar el comprimido en 
un proyecto base con los nodes_modules y ejecutar el comando 
ng serve. 


