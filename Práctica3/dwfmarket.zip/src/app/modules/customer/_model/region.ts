export class Region{
    id_region: number;
    region: string;

    constructor(){
        this.id_region = 0;
        this.region = "";
    }
}