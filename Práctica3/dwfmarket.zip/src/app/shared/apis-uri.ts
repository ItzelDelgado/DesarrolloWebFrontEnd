export class ApisURI{
    public static exchangeRateURI: string = "https://api.exchangerate-api.com/v4/latest/{rate}";
    public static dwf20220apiURI: string = "http://localhost:8080";
}